# Gradesheet Verify — web frontend

A local browser UI for `gradesheet_verify.py`. Instead of typing folder
paths on the command line, you browse or drag-and-drop a PDF folder and
your spreadsheet from anywhere on your computer.

## Setup

```bash
cd gradesheet_web
pip install -r requirements.txt
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

## Use

1. Click the first box to pick a **folder** of grade-sheet PDFs (or use the
   small "loose files" picker to select individual PDFs instead), or just
   drag a folder onto it.
2. Click the second box to pick your `.xlsx` spreadsheet, or drag it in.
3. (Optional) Open "Column mapping & matching mode" to set the header row,
   registration/name columns, columns to check, and matching strictness.
   Leave these blank and it will auto-detect.
4. Click **Run check**. When it finishes, download `report.xlsx`.

## Notes

- Everything runs locally on your machine — uploaded files are saved under
  `uploads/<job-id>/` and reports under `reports/`. Nothing leaves your
  computer.
- `app.py` just calls the original `gradesheet_verify.py` with the paths
  it saved your upload to, so all of that script's matching logic is
  unchanged.
- Folder upload (`webkitdirectory`) works in Chrome, Edge, and Safari.
  Firefox users should use the drag-and-drop option or the loose-files
  picker.
- To clear old uploads/reports, just delete the `uploads/` and `reports/`
  folders' contents.
