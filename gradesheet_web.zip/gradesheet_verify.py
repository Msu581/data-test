#!/usr/bin/env python3
"""
gradesheet_verify.py — verify grade-sheet PDFs against a spreadsheet.

Reads a folder of grade-sheet PDFs, matches each spreadsheet row to its PDF by
registration number, and compares the values the spreadsheet claims against the
values actually printed on the grade sheet. Every difference is classified and
explained, down to the Unicode code point.

Required:  pip install pdfplumber openpyxl
Optional:  pip install rapidfuzz tqdm      (faster fuzzy matching, progress bar)

    python gradesheet_verify.py --pdfs ./pdfs --excel "Error sheet.xlsx"

Run with no column arguments and it will show you the sheet and ask which
columns to use. Give the arguments and it runs unattended, which is what you
want from cron or CI.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import sys
import time
import unicodedata
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass, field, asdict
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterable, Optional

__version__ = "1.0.0"

# ----------------------------------------------------------------------------
# optional dependencies
# ----------------------------------------------------------------------------
try:
    from rapidfuzz.distance import Levenshtein as _RFLev
    from rapidfuzz import fuzz as _rf_fuzz

    def edit_distance(a: str, b: str) -> int:
        return _RFLev.distance(a, b)

    def ratio(a: str, b: str) -> float:
        return _rf_fuzz.ratio(a, b) / 100.0

    HAVE_RAPIDFUZZ = True
except ImportError:  # pragma: no cover - fallback path
    import difflib

    HAVE_RAPIDFUZZ = False

    def edit_distance(a: str, b: str) -> int:
        if a == b:
            return 0
        prev = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            cur = [i]
            for j, cb in enumerate(b, 1):
                cur.append(min(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + (ca != cb)))
            prev = cur
        return prev[-1]

    def ratio(a: str, b: str) -> float:
        return difflib.SequenceMatcher(None, a, b).ratio()


try:
    from tqdm import tqdm as _tqdm
    HAVE_TQDM = True
except ImportError:  # pragma: no cover
    HAVE_TQDM = False
    _tqdm = None


class Progress:
    """A tqdm bar when tqdm is installed, a plain counter when it is not."""

    def __init__(self, total: int, desc: str, enabled: bool = True):
        self.total, self.done, self.enabled = total, 0, enabled
        self.desc = desc
        self.bar = _tqdm(total=total, desc=desc, unit="file", leave=False) if (
            HAVE_TQDM and enabled) else None
        self._last = 0.0

    def update(self, n: int = 1) -> None:
        self.done += n
        if self.bar is not None:
            self.bar.update(n)
        elif self.enabled:
            now = time.time()
            if now - self._last > 0.4 or self.done == self.total:
                self._last = now
                pct = 100 * self.done // max(1, self.total)
                sys.stdout.write(f"\r{self.desc} {self.done}/{self.total} ({pct}%)   ")
                sys.stdout.flush()

    def close(self) -> None:
        if self.bar is not None:
            self.bar.close()
        elif self.enabled:
            sys.stdout.write("\r" + " " * 60 + "\r")
            sys.stdout.flush()


# ----------------------------------------------------------------------------
# text normalisation
# ----------------------------------------------------------------------------

# Characters that render as ordinary whitespace but are not U+0020.
ODD_SPACES = {
    "\u00a0": "NO-BREAK SPACE",
    "\u1680": "OGHAM SPACE MARK",
    "\u2000": "EN QUAD", "\u2001": "EM QUAD", "\u2002": "EN SPACE",
    "\u2003": "EM SPACE", "\u2004": "THREE-PER-EM SPACE",
    "\u2005": "FOUR-PER-EM SPACE", "\u2006": "SIX-PER-EM SPACE",
    "\u2007": "FIGURE SPACE", "\u2008": "PUNCTUATION SPACE",
    "\u2009": "THIN SPACE", "\u200a": "HAIR SPACE",
    "\u202f": "NARROW NO-BREAK SPACE", "\u205f": "MEDIUM MATHEMATICAL SPACE",
    "\u3000": "IDEOGRAPHIC SPACE",
}
# Characters with zero width. These are invisible and break every text search.
ZERO_WIDTH = {
    "\u200b": "ZERO WIDTH SPACE", "\u200c": "ZERO WIDTH NON-JOINER",
    "\u200d": "ZERO WIDTH JOINER", "\u2060": "WORD JOINER",
    "\ufeff": "ZERO WIDTH NO-BREAK SPACE (BOM)",
    "\u00ad": "SOFT HYPHEN", "\u180e": "MONGOLIAN VOWEL SEPARATOR",
}
# Non-Latin letters that are visually identical to a Latin letter. A name that
# contains one of these will never match, and nothing on screen shows why.
CONFUSABLES = {
    "\u0410": "A", "\u0412": "B", "\u0415": "E", "\u041a": "K", "\u041c": "M",
    "\u041d": "H", "\u041e": "O", "\u0420": "P", "\u0421": "C", "\u0422": "T",
    "\u0423": "Y", "\u0425": "X", "\u0430": "a", "\u0435": "e", "\u043e": "o",
    "\u0440": "p", "\u0441": "c", "\u0443": "y", "\u0445": "x", "\u0456": "i",
    "\u0391": "A", "\u0392": "B", "\u0395": "E", "\u0396": "Z", "\u0397": "H",
    "\u0399": "I", "\u039a": "K", "\u039c": "M", "\u039d": "N", "\u039f": "O",
    "\u03a1": "P", "\u03a4": "T", "\u03a7": "X", "\u03bf": "o",
    "\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-", "\u2014": "-",
    "\u2015": "-", "\u2212": "-",
    "\u2018": "'", "\u2019": "'", "\u201b": "'", "\u02bc": "'",
    "\u201c": '"', "\u201d": '"',
    "\uff10": "0", "\uff11": "1", "\uff12": "2", "\uff13": "3", "\uff14": "4",
    "\uff15": "5", "\uff16": "6", "\uff17": "7", "\uff18": "8", "\uff19": "9",
}
# Digits an OCR engine most often swaps.
OCR_DIGIT_PAIRS = {
    frozenset("01"), frozenset("05"), frozenset("06"), frozenset("08"),
    frozenset("17"), frozenset("15"), frozenset("35"), frozenset("38"),
    frozenset("58"), frozenset("69"), frozenset("89"),
}
# Prefixes that carry no identity: honorifics and relationship markers.
HONORIFICS = {
    "mr", "mrs", "ms", "miss", "dr", "prof", "shri", "sri", "smt", "kum",
    "late", "md", "mohd", "st", "sh", "m/s",
}
RELATION_PREFIX = re.compile(r"^\s*(s\s*/\s*o|d\s*/\s*o|w\s*/\s*o|c\s*/\s*o)\b[.: ]*", re.I)


def clean(value: Any) -> str:
    """Normalise invisible and look-alike characters without changing meaning."""
    if value is None:
        return ""
    s = str(value)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    out = []
    for ch in s:
        if ch in ZERO_WIDTH:
            continue
        if ch in ODD_SPACES:
            out.append(" ")
        elif ch in CONFUSABLES:
            out.append(CONFUSABLES[ch])
        else:
            out.append(ch)
    return "".join(out)


def collapsed(value: Any) -> str:
    return re.sub(r"\s+", " ", clean(value)).strip()


def lowered(value: Any) -> str:
    return collapsed(value).lower()


def deaccent(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if not unicodedata.combining(c))


def alnum(value: Any) -> str:
    s = deaccent(lowered(value))
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", " ", s)).strip()


def squashed(value: Any) -> str:
    return alnum(value).replace(" ", "")


def digits_of(value: Any) -> str:
    return re.sub(r"\D+", "", clean(value))


def tokens(value: Any) -> list[str]:
    a = alnum(value)
    return a.split(" ") if a else []


def strip_honorifics(value: str) -> tuple[str, list[str]]:
    """Remove leading titles and S/o-style prefixes. Returns (text, removed)."""
    removed: list[str] = []
    s = clean(value).strip()
    m = RELATION_PREFIX.match(s)
    while m:
        removed.append(m.group(1).upper().replace(" ", ""))
        s = s[m.end():]
        m = RELATION_PREFIX.match(s)
    parts = s.split()
    while parts and re.sub(r"[.]", "", parts[0]).lower() in HONORIFICS:
        removed.append(parts.pop(0))
    return " ".join(parts), removed


def codepoint_note(ch: str) -> str:
    try:
        name = unicodedata.name(ch)
    except ValueError:
        name = "unnamed control character"
    return f"U+{ord(ch):04X} {name}"


def odd_characters(value: Any) -> list[str]:
    """Every character in the raw value that is invisible or a look-alike."""
    found: list[str] = []
    seen: set[str] = set()
    for ch in str(value or ""):
        if ch in seen:
            continue
        if ch in ZERO_WIDTH or ch in ODD_SPACES or ch in CONFUSABLES:
            seen.add(ch)
            hint = ""
            if ch in CONFUSABLES and CONFUSABLES[ch].isalnum():
                hint = f" — looks exactly like \u201c{CONFUSABLES[ch]}\u201d but is not"
            elif ch in ZERO_WIDTH:
                hint = " — invisible, and it breaks every text search"
            found.append(codepoint_note(ch) + hint)
    return found


def scripts_used(value: str) -> set[str]:
    out = set()
    for ch in value:
        if not ch.isalpha():
            continue
        try:
            name = unicodedata.name(ch)
        except ValueError:
            continue
        out.add(name.split(" ")[0])
    return out

# ----------------------------------------------------------------------------
# the fields a grade sheet carries
# ----------------------------------------------------------------------------

@dataclass(frozen=True)
class FieldDef:
    key: str
    label: str
    kind: str                 # name | date | id | number | text
    aliases: tuple[str, ...]


FIELDS: tuple[FieldDef, ...] = (
    FieldDef("student_name", "Student name", "name",
             ("name of student", "student name", "name of the student", "candidate name",
              "name of candidate", "student", "name", "candidates name", "name of the candidate")),
    FieldDef("father_name", "Father's name", "name",
             ("fathers name", "father name", "name of father", "father", "fathers",
              "father / guardian name", "fathers guardians name")),
    FieldDef("mother_name", "Mother's name", "name",
             ("mothers name", "mother name", "name of mother", "mother", "mothers")),
    FieldDef("guardian_name", "Guardian's name", "name",
             ("guardians name", "guardian name", "name of guardian", "guardian")),
    FieldDef("dob", "Date of birth", "date",
             ("date of birth", "dob", "d o b", "birth date", "date of birth dd mm yyyy")),
    FieldDef("aadhaar", "Aadhaar number", "id",
             ("aadhaar no", "aadhar no", "aadhaar number", "aadhar number", "aadhaar",
              "aadhar", "uid no")),
    FieldDef("abc_id", "ABC ID", "id",
             ("abc id", "abcid", "academic bank of credits id", "apaar id")),
    FieldDef("registration", "Registration number", "id",
             ("registration no", "registration number", "reg no", "enrollment no",
              "enrolment no", "enrollment number", "enrolment number", "enrollment",
              "enrolment", "roll no", "roll number", "university roll no", "student id",
              "admission no", "registration")),
    FieldDef("programme", "Programme", "text",
             ("programme", "program", "degree", "programme name", "course", "course name")),
    FieldDef("specialization", "Specialization", "text",
             ("specialization", "specialisation", "branch", "stream", "discipline")),
    FieldDef("semester", "Semester", "text", ("semester", "sem", "term")),
    FieldDef("category", "Category", "text",
             ("category", "student category", "candidate category")),
    FieldDef("school", "School", "text", ("school", "faculty", "department")),
    FieldDef("year_admission", "Year of admission", "text",
             ("year of admission", "admission year", "session", "academic year", "batch")),
    FieldDef("gender", "Gender", "text", ("gender", "sex")),
    FieldDef("nationality", "Nationality", "text", ("nationality",)),
    FieldDef("sgpa", "SGPA", "number", ("sgpa", "semester gpa")),
    FieldDef("cgpa", "CGPA", "number", ("cgpa",)),
    FieldDef("percentage", "Percentage of marks", "number",
             ("percentage of marks", "percentage", "percent of marks", "marks percentage")),
    FieldDef("total_marks", "Total marks", "number", ("total marks", "marks obtained")),
    FieldDef("max_marks", "Maximum marks", "number", ("maximum marks", "max marks")),
    FieldDef("total_credits", "Total credits", "number", ("total credits",)),
    FieldDef("credit_points", "Grand total credit points", "number",
             ("grand total credit points", "total credit points", "credit points")),
    FieldDef("result", "Result", "text", ("result", "result status")),
    FieldDef("issue_date", "Date", "date", ("date", "date of issue", "issued on")),
)

_ALIAS: dict[str, FieldDef] = {}
for _f in FIELDS:
    for _a in _f.aliases:
        _ALIAS[squashed(_a)] = _f
    _ALIAS[squashed(_f.label)] = _f
    _ALIAS[squashed(_f.key.replace("_", " "))] = _f

_PAREN = re.compile(r"\(.*?\)")
_AS_PER = re.compile(r"\s+as per.*$", re.I)


def label_key(raw: str) -> str:
    s = _AS_PER.sub("", _PAREN.sub(" ", lowered(raw)))
    return squashed(s)


def exact_field(raw_label: str) -> Optional[FieldDef]:
    """A field only when the label is one we know verbatim."""
    return _ALIAS.get(label_key(raw_label))


def resolve_field(raw_label: str) -> Optional[FieldDef]:
    """A field, allowing for a typo in the label."""
    k = label_key(raw_label)
    if not k:
        return None
    if k in _ALIAS:
        return _ALIAS[k]
    if len(k) < 4:
        return None
    best, best_score = None, 0.0
    for alias, fdef in _ALIAS.items():
        if abs(len(alias) - len(k)) > 2:
            continue
        sc = ratio(k, alias)
        if sc > best_score:
            best_score, best = sc, fdef
    return best if best_score >= 0.88 else None


# ----------------------------------------------------------------------------
# reading a PDF
# ----------------------------------------------------------------------------

COLUMN_GAP = 20.0      # points; a wider gap than this starts a second column
LINE_TOLERANCE = 3.2   # points; words this close share a baseline

LABEL_RE = re.compile(r"([A-Za-z][A-Za-z0-9 .'&()/-]{1,44}?)\s*:\s*")
WORD_RE = re.compile(r"[A-Za-z0-9.'&()/-]+")
COLON_RE = re.compile(r"\s*:\s*")
MAX_LABEL = 45


def parse_segment(seg: str) -> list[tuple[str, str]]:
    """Split one segment into label/value pairs.

    A colon alone is not enough to mark a label. When a long value runs up
    against the next column the two merge into one segment, and a naive scan
    then treats the tail of the value as the next label and truncates it. So a
    colon that is not the first in the segment only starts a new field if the
    words before it actually name one.
    """
    accepted: list[tuple[int, str, int]] = []
    cursor, first = 0, True
    for m in COLON_RE.finditer(seg):
        colon_at, after = m.start(), m.end()
        if colon_at < cursor:
            continue
        head = seg[cursor:colon_at]
        words = list(WORD_RE.finditer(head))
        if not words:
            continue
        # An exact label wins over a fuzzy one, and among exact labels the
        # longest wins, so "Name of Student" beats a bare "Student" and
        # "700 Percentage of Marks" never beats "Percentage of Marks".
        chosen: Optional[tuple[int, str]] = None
        fuzzy: Optional[tuple[int, str]] = None
        for k in range(1, min(6, len(words)) + 1):
            start = words[-k].start()
            cand = head[start:].strip()
            if len(cand) > MAX_LABEL:
                break
            if exact_field(cand):
                chosen = (cursor + start, cand)
            elif fuzzy is None and resolve_field(cand):
                fuzzy = (cursor + start, cand)
        if chosen is None:
            chosen = fuzzy
        if chosen is None and first:
            cand = head.strip()
            if cand and len(cand) <= MAX_LABEL:
                chosen = (cursor + (len(head) - len(head.lstrip())), cand)
        if chosen is None:
            continue
        accepted.append((chosen[0], chosen[1], after))
        cursor, first = after, False

    pairs: list[tuple[str, str]] = []
    for i, (_, label, value_at) in enumerate(accepted):
        stop = accepted[i + 1][0] if i + 1 < len(accepted) else len(seg)
        value = seg[value_at:stop].strip()
        if value:
            pairs.append((label, value))
    return pairs


@dataclass
class PdfRecord:
    """One student's grade sheet. A single PDF may hold several."""
    file: str
    pages: list[int] = field(default_factory=list)
    registration: str = ""
    fields: dict[str, str] = field(default_factory=dict)
    loose: dict[str, str] = field(default_factory=dict)
    text: str = ""

    def value(self, fdef: Optional[FieldDef], raw_label: str = "") -> str:
        if fdef and fdef.key in self.fields:
            return self.fields[fdef.key]
        lk = label_key(raw_label)
        if lk and lk in self.loose:
            return self.loose[lk]
        if raw_label:
            pat = re.escape(collapsed(raw_label)).replace(r"\ ", r"\s*")
            m = re.search(pat + r"\s*:\s*([^\n]{1,160})", self.text, re.I)
            if m:
                return m.group(1).strip()
        if fdef:
            for alias in fdef.aliases:
                pat = re.escape(alias).replace(r"\ ", r"\s*")
                m = re.search(r"\b" + pat + r"\.?\s*:\s*([^\n]{1,160})", self.text, re.I)
                if m:
                    return m.group(1).strip()
        return ""


def words_to_segments(words: list[dict]) -> list[list[str]]:
    """Group pdfplumber words into lines, then into column segments.

    Grade sheets put two label/value pairs side by side and align the colons,
    so a naive read joins the left column's value onto the right column's label.
    Splitting on the wide gaps and then stitching the colon back on fixes both.
    """
    lines: list[list[dict]] = []
    for w in sorted(words, key=lambda w: (round(w["top"], 1), w["x0"])):
        placed = False
        for ln in reversed(lines[-4:]):
            if abs(ln[0]["top"] - w["top"]) < LINE_TOLERANCE:
                ln.append(w)
                placed = True
                break
        if not placed:
            lines.append([w])

    out: list[list[str]] = []
    for ln in lines:
        ln.sort(key=lambda w: w["x0"])
        segs: list[str] = []
        cur = ""
        end: Optional[float] = None
        for w in ln:
            if end is None:
                cur = w["text"]
            elif w["x0"] - end > COLUMN_GAP:
                segs.append(cur)
                cur = w["text"]
            else:
                cur = f"{cur} {w['text']}" if cur and not cur.endswith(" ") else cur + w["text"]
            end = w["x1"]
        if cur:
            segs.append(cur)

        merged: list[str] = []
        for s in segs:
            s = s.rstrip()
            if not s.strip():
                continue
            if merged and (s.lstrip().startswith(":") or merged[-1].rstrip().endswith(":")):
                merged[-1] = merged[-1].rstrip() + " " + s.lstrip()
            else:
                merged.append(s)
        if merged:
            out.append(merged)
    return out


def harvest(segments: list[list[str]]) -> tuple[dict[str, str], dict[str, str]]:
    canonical: dict[str, str] = {}
    loose: dict[str, str] = {}
    for line in segments:
        for seg in line:
            for raw, val in parse_segment(seg):
                lk = label_key(raw)
                if lk:
                    loose.setdefault(lk, val)
                fdef = resolve_field(raw)
                if fdef:
                    canonical.setdefault(fdef.key, val)
    return canonical, loose


def read_pdf(path: str, max_pages: int = 6) -> dict:
    """Extract every student record from one PDF. Safe to call in a subprocess."""
    import pdfplumber
    import logging
    logging.getLogger("pdfminer").setLevel(logging.ERROR)

    name = os.path.basename(path)
    try:
        pages_out: list[tuple[int, list[list[str]], str]] = []
        with pdfplumber.open(path) as pdf:
            total = len(pdf.pages)
            for i, page in enumerate(pdf.pages[:max_pages], start=1):
                words = page.extract_words(keep_blank_chars=False, use_text_flow=False)
                segs = words_to_segments(words)
                pages_out.append((i, segs, "\n".join("    ".join(s) for s in segs)))
                page.flush_cache()
    except Exception as exc:  # a corrupt or encrypted file must not stop the run
        return {"ok": False, "file": name, "path": path, "error": f"{type(exc).__name__}: {exc}",
                "records": [], "pages": 0}

    records: list[dict] = []
    cur: Optional[dict] = None
    for pno, segs, text in pages_out:
        canon, loose = harvest(segs)
        reg = digits_of(canon.get("registration", ""))
        if reg and (cur is None or (cur["registration"] and cur["registration"] != reg)):
            cur = {"file": name, "path": path, "pages": [pno], "registration": reg,
                   "fields": {}, "loose": {}, "text": ""}
            records.append(cur)
        elif cur is None:
            cur = {"file": name, "path": path, "pages": [pno], "registration": "",
                   "fields": {}, "loose": {}, "text": ""}
            records.append(cur)
        else:
            cur["pages"].append(pno)
            if reg and not cur["registration"]:
                cur["registration"] = reg
        for k, v in canon.items():
            cur["fields"].setdefault(k, v)
        for k, v in loose.items():
            cur["loose"].setdefault(k, v)
        cur["text"] = (cur["text"] + "\n" + text) if cur["text"] else text

    empty = all(not r["fields"] for r in records)
    return {"ok": True, "file": name, "path": path, "pages": total,
            "records": records, "no_text": empty}


def file_digest(path: str) -> str:
    h = hashlib.sha256()
    h.update(str(os.path.getsize(path)).encode())
    with open(path, "rb") as fh:
        h.update(fh.read(262144))
        try:
            fh.seek(-262144, os.SEEK_END)
            h.update(fh.read())
        except OSError:
            pass
    return h.hexdigest()[:24]


class ExtractionCache:
    """Keeps parsed PDF text on disk so a second run with different settings
    does not re-parse a thousand files."""

    def __init__(self, path: Optional[Path]):
        self.path = path
        self.data: dict[str, dict] = {}
        self.hits = 0
        if path and path.exists():
            try:
                self.data = json.loads(path.read_text("utf-8"))
            except Exception:
                self.data = {}

    def get(self, key: str) -> Optional[dict]:
        hit = self.data.get(key)
        if hit is not None:
            self.hits += 1
        return hit

    def put(self, key: str, value: dict) -> None:
        self.data[key] = value

    def save(self) -> None:
        if not self.path:
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self.data), "utf-8")
        except OSError:
            pass


# ----------------------------------------------------------------------------
# the verdict engine
# ----------------------------------------------------------------------------

PASS, WARN, FAIL = "pass", "warn", "fail"

# How each class of difference is graded in each mode.
SEVERITY: dict[str, dict[str, str]] = {
    "lenient":  {"WS": PASS, "CASE": PASS, "PUNCT": PASS, "DIACRITIC": PASS,
                 "FORMAT": PASS, "HONORIFIC": PASS, "ODDCHAR": WARN,
                 "ORDER": WARN, "INITIAL": WARN, "SPELL": FAIL, "WORDS": FAIL, "DIFF": FAIL},
    "standard": {"WS": WARN, "CASE": WARN, "PUNCT": WARN, "DIACRITIC": WARN,
                 "FORMAT": WARN, "HONORIFIC": WARN, "ODDCHAR": WARN,
                 "ORDER": FAIL, "INITIAL": FAIL, "SPELL": FAIL, "WORDS": FAIL, "DIFF": FAIL},
    "strict":   {"WS": FAIL, "CASE": FAIL, "PUNCT": FAIL, "DIACRITIC": FAIL,
                 "FORMAT": FAIL, "HONORIFIC": FAIL, "ODDCHAR": FAIL,
                 "ORDER": FAIL, "INITIAL": FAIL, "SPELL": FAIL, "WORDS": FAIL, "DIFF": FAIL},
    # forensic is strict plus a full code-point report on every field it touches
    "forensic": {"WS": FAIL, "CASE": FAIL, "PUNCT": FAIL, "DIACRITIC": FAIL,
                 "FORMAT": FAIL, "HONORIFIC": FAIL, "ODDCHAR": FAIL,
                 "ORDER": FAIL, "INITIAL": FAIL, "SPELL": FAIL, "WORDS": FAIL, "DIFF": FAIL},
}

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
MONTHS.update({m: i for i, m in enumerate(
    ["january", "february", "march", "april", "may", "june", "july", "august",
     "september", "october", "november", "december"], 1)})
MONTHS["sept"] = 9
MONTH_NAMES = ["", "January", "February", "March", "April", "May", "June", "July",
               "August", "September", "October", "November", "December"]


def as_date(value: Any) -> Optional[tuple[int, int, int]]:
    if isinstance(value, (datetime, date)):
        return (value.year, value.month, value.day)
    s = collapsed(value)
    if not s:
        return None
    m = re.fullmatch(r"(\d{1,2})[-/. ](\d{1,2})[-/. ](\d{2,4})", s)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 1900 if y > 50 else 2000
        if mo > 12 and d <= 12:
            d, mo = mo, d
        if 1 <= mo <= 12 and 1 <= d <= 31 and 1900 < y < 2100:
            return (y, mo, d)
        return None
    m = re.fullmatch(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", s)
    if m:
        return (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    m = re.fullmatch(r"(\d{1,2})[ -]([A-Za-z]{3,9})\.?[ ,-]+(\d{4})", s)
    if m and m.group(2).lower() in MONTHS:
        return (int(m.group(3)), MONTHS[m.group(2).lower()], int(m.group(1)))
    m = re.fullmatch(r"([A-Za-z]{3,9})\.? (\d{1,2}),? (\d{4})", s)
    if m and m.group(1).lower() in MONTHS:
        return (int(m.group(3)), MONTHS[m.group(1).lower()], int(m.group(2)))
    return None


def fmt_date(t: tuple[int, int, int]) -> str:
    return f"{t[2]} {MONTH_NAMES[t[1]]} {t[0]}"


def id_digits(value: Any) -> tuple[str, bool]:
    """Digits of an identifier. Excel turns long IDs into 2.51512E+11 and that
    display string silently loses the real number, so flag it when seen."""
    s = collapsed(value)
    sci = bool(re.fullmatch(r"[+-]?\d+(\.\d+)?[eE][+-]?\d+", s))
    if sci:
        try:
            s = f"{float(s):.0f}"
        except ValueError:
            pass
    s = re.sub(r"\.0+$", "", s)
    return digits_of(s), sci


def as_number(value: Any) -> Optional[float]:
    s = collapsed(value).replace(",", "").rstrip("%")
    try:
        return float(s)
    except ValueError:
        return None


def quote(s: Any) -> str:
    return f"\u201c{s}\u201d"


def plural(n: int, one: str, many: str) -> str:
    return f"{n} {one if n == 1 else many}"


def listing(items: list[str], limit: int = 8) -> str:
    head = ", ".join(quote(x) for x in items[:limit])
    rest = len(items) - limit
    return head + (f" and {rest} more" if rest > 0 else "")


@dataclass
class Verdict:
    code: str
    verdict: str
    summary: str
    details: list[str] = field(default_factory=list)
    similarity: float = 0.0


def _spacing_details(a: str, b: str) -> list[str]:
    out: list[str] = []
    ca, cb = clean(a), clean(b)
    a_edge, b_edge = ca != ca.strip(), cb != cb.strip()
    if a_edge or b_edge:
        s = ca if a_edge else cb
        lead, tail = s[:1].isspace(), s[-1:].isspace()
        where = ("a space before and after the text" if lead and tail
                 else "a space before the text" if lead else "a space after the text")
        who = ("Both values have" if a_edge and b_edge
               else "The spreadsheet value has" if a_edge else "The PDF value has")
        out.append(f"{who} {where}. It is invisible in the cell and still counts as a difference.")
    da = len(re.findall(r"\s{2,}", ca.strip()))
    db = len(re.findall(r"\s{2,}", cb.strip()))
    if da or db:
        who = ("Both values contain" if da and db
               else "The spreadsheet value contains" if da else "The PDF value contains")
        out.append(f"{who} a run of two or more spaces between words.")
    if not out:
        out.append("The two values differ only in whitespace.")
    return out


def _case_details(a: str, b: str) -> list[str]:
    ca, cb = collapsed(a), collapsed(b)
    spots, n = [], 0
    for i, (x, y) in enumerate(zip(ca, cb), 1):
        if x != y:
            n += 1
            if len(spots) < 4:
                spots.append(f"position {i} ({quote(x)} vs {quote(y)})")
    out = [f"Same letters in the same order; the capitalisation differs at {plural(n, 'letter', 'letters')}."]
    if spots:
        out.append("First differences: " + ", ".join(spots) + ".")
    if ca.isupper():
        out.append("The spreadsheet value is in full capitals, which usually means it was pasted in from another system.")
    if cb.isupper():
        out.append("The PDF value is in full capitals.")
    return out


def _punct_details(a: str, b: str) -> list[str]:
    out = ["The letters and digits are identical; only punctuation or symbols differ."]
    pa = Counter(c for c in collapsed(a) if not c.isalnum() and c != " ")
    pb = Counter(c for c in collapsed(b) if not c.isalnum() and c != " ")
    only_a = list((pa - pb).elements())
    only_b = list((pb - pa).elements())
    if only_a:
        out.append("Only in the spreadsheet: " + listing(only_a) + ".")
    if only_b:
        out.append("Only in the PDF: " + listing(only_b) + ".")
    return out


def _word_units(value: str) -> list[tuple[str, str]]:
    out = []
    for w in collapsed(value).split(" "):
        n = re.sub(r"[^a-z0-9]", "", deaccent(w.lower()))
        if n:
            out.append((w, n))
    return out


def _is_initial_of(short: str, long: str) -> bool:
    s = short.replace(".", "")
    return bool(s) and len(s) <= 3 and len(s) < len(long) and long.startswith(s)


def _word_details(a: str, b: str) -> tuple[str, list[str], dict[str, int]]:
    ua, ub = _word_units(a), _word_units(b)
    pool = list(ub)
    only_a: list[tuple[str, str]] = []
    for orig, norm in ua:
        for i, (_, n2) in enumerate(pool):
            if n2 == norm:
                pool.pop(i)
                break
        else:
            only_a.append((orig, norm))
    only_b = pool

    used: set[int] = set()
    pairs: list[tuple[tuple[str, str], tuple[str, str]]] = []
    left_a: list[tuple[str, str]] = []
    for u in only_a:
        best, best_sc = -1, 0.0
        for i, v in enumerate(only_b):
            if i in used:
                continue
            sc = ratio(u[1], v[1])
            if _is_initial_of(u[1], v[1]) or _is_initial_of(v[1], u[1]):
                sc = max(sc, 0.9)
            if sc > best_sc:
                best_sc, best = sc, i
        if best >= 0 and best_sc >= 0.55:
            used.add(best)
            pairs.append((u, only_b[best]))
        else:
            left_a.append(u)
    left_b = [v for i, v in enumerate(only_b) if i not in used]

    details: list[str] = []
    spellings = initials = 0
    for (ao, an), (bo, bn) in pairs:
        if _is_initial_of(an, bn):
            initials += 1
            details.append(f"Short form: the spreadsheet has {quote(ao)} where the PDF spells out {quote(bo)}.")
        elif _is_initial_of(bn, an):
            initials += 1
            details.append(f"Short form: the PDF has {quote(bo)} where the spreadsheet spells out {quote(ao)}.")
        else:
            spellings += 1
            d = edit_distance(an, bn)
            pos = next((i for i, (x, y) in enumerate(zip(an, bn), 1) if x != y), None)
            where = ""
            if pos:
                where = f", first at letter {pos} ({quote(an[pos-1])} against {quote(bn[pos-1])})"
            elif len(an) != len(bn):
                where = f", one is {abs(len(an)-len(bn))} letter(s) longer"
            details.append(
                f"Spelling: spreadsheet {quote(ao)} against PDF {quote(bo)} — "
                f"{plural(d, 'letter differs', 'letters differ')}{where}.")
    if left_a:
        details.append("In the spreadsheet but not in the PDF: " + listing([x[0] for x in left_a]) + ".")
    if left_b:
        details.append("In the PDF but not in the spreadsheet: " + listing([x[0] for x in left_b]) + ".")
    if len(ua) != len(ub):
        details.append(f"Word count: {len(ua)} in the spreadsheet against {len(ub)} in the PDF.")

    code = "SPELL" if spellings else ("INITIAL" if initials else "WORDS")
    counts = {"spellings": spellings, "initials": initials,
              "missing": len(left_a), "extra": len(left_b)}
    return code, details, counts


def compare(excel_value: Any, pdf_value: Any, kind: str, mode: str,
            ignore_honorifics: bool = False) -> Verdict:
    sev = SEVERITY.get(mode, SEVERITY["standard"])
    a_raw = "" if excel_value is None else str(excel_value)
    b_raw = "" if pdf_value is None else str(pdf_value)

    if not clean(a_raw).strip():
        return Verdict("EMPTY_EXCEL", WARN,
                       "Nothing to check — the spreadsheet cell is empty for this field.")
    if not clean(b_raw).strip():
        return Verdict("MISSING_IN_PDF", FAIL,
                       "This field could not be found in the PDF.",
                       ["The label is not present in the text of the grade sheet, or the value "
                        "beside it is blank.",
                        "If the PDF is a scan with no text layer, nothing can be read from it; "
                        "run OCR over it first."])

    sim = ratio(alnum(a_raw), alnum(b_raw))

    # Invisible and look-alike characters are reported whatever the verdict,
    # because they are the one class of fault a human proof-reader cannot see.
    odd = [f"Spreadsheet value contains {n}" for n in odd_characters(a_raw)]
    odd += [f"PDF value contains {n}" for n in odd_characters(b_raw)]
    mixed = scripts_used(clean(a_raw)) | scripts_used(clean(b_raw))
    if len(mixed) > 1:
        odd.append("Mixed alphabets in play (" + ", ".join(sorted(mixed)).title() +
                   "). A name typed partly in one script and partly in another will never match.")

    def done(v: Verdict) -> Verdict:
        v.similarity = sim
        if odd:
            v.details = list(v.details) + odd
            if v.verdict == PASS and sev["ODDCHAR"] != PASS:
                v.verdict = sev["ODDCHAR"]
                v.summary = "Values agree once invisible characters are normalised."
        if mode == "forensic":
            v.details = list(v.details) + _forensic_report(a_raw, b_raw)
        return v

    if a_raw == b_raw:
        return done(Verdict("EXACT", PASS, "Exact match."))

    if clean(a_raw) == clean(b_raw) and odd:
        return done(Verdict(
            "ODDCHAR", sev["ODDCHAR"],
            "Identical once invisible or look-alike characters are removed.",
            ["To a reader these are the same value. They differ only in characters that are "
             "invisible on screen, or that imitate a Latin letter, which is why an exact "
             "comparison fails and a find-and-replace will not fix it."]))

    if collapsed(a_raw) == collapsed(b_raw):
        return done(Verdict("WS", sev["WS"], "Same text, different spacing.",
                            _spacing_details(a_raw, b_raw)))

    if lowered(a_raw) == lowered(b_raw):
        return done(Verdict("CASE", sev["CASE"], "Same text, different capitalisation.",
                            _case_details(a_raw, b_raw)))

    if kind == "date":
        da, db = as_date(a_raw), as_date(b_raw)
        if da and db:
            if da == db:
                return done(Verdict("FORMAT", sev["FORMAT"],
                                    "Same date, written in a different format.",
                                    [f"Both resolve to {fmt_date(da)}; only the separators or the "
                                     f"order of day, month and year differ."]))
            det = [f"The spreadsheet gives {fmt_date(da)}; the PDF gives {fmt_date(db)}."]
            if da[0] != db[0]:
                det.append("The year differs.")
            elif da[1] != db[1]:
                det.append("The month differs.")
                if da[1] == db[2] and da[2] == db[1]:
                    det.append("Day and month are swapped — one side was read as mm-dd and the "
                               "other as dd-mm.")
            else:
                det.append("The day differs.")
            return done(Verdict("DIFF", FAIL, "Different date.", det))

    if kind == "id":
        xa, sci_a = id_digits(a_raw)
        xb, sci_b = id_digits(b_raw)
        if xa and xb:
            if xa == xb:
                return done(Verdict("FORMAT", sev["FORMAT"], "Same number, written differently.",
                                    [f"Both reduce to {xa}. Spaces, dashes, or a trailing “.0” "
                                     f"that Excel adds to a number account for the difference."]))
            masked = (re.fullmatch(r"[xX*]{2,}\d*", collapsed(a_raw).replace(" ", "")) or
                      re.fullmatch(r"[xX*]{2,}\d*", collapsed(b_raw).replace(" ", "")))
            if masked and xa[-4:] == xb[-4:]:
                return done(Verdict("FORMAT", sev["FORMAT"],
                                    "One side is masked, and the visible digits agree.",
                                    [f"Only the last four digits are printed on one side and they "
                                     f"match ({xa[-4:]}). The rest cannot be checked."]))
            det: list[str] = []
            if sci_a or sci_b:
                det.append("Excel stored this as a number and showed it in scientific notation, "
                           "which silently drops the real digits. Format that column as Text and "
                           "re-enter the value.")
            if len(xa) != len(xb):
                det.append(f"Digit count differs: {len(xa)} in the spreadsheet against "
                           f"{len(xb)} in the PDF.")
            det.append(f"{plural(edit_distance(xa, xb), 'digit differs', 'digits differ')} "
                       f"between {xa} and {xb}.")
            for side, value in (("spreadsheet", a_raw), ("PDF", b_raw)):
                letters = sorted(set(re.findall(r"[OoIlSBZ]", collapsed(value))))
                if letters and re.search(r"\d", collapsed(value)):
                    det.append(f"The {side} value mixes letters into a number "
                               f"({', '.join(quote(c) for c in letters)}). O is often typed for "
                               f"0, l or I for 1, S for 5, B for 8 and Z for 2.")
            if sorted(xa) == sorted(xb):
                det.append("The same digits appear on both sides in a different order. "
                           "That is a transposition typo, not a different student.")
            if len(xa) == len(xb):
                swaps = [(i + 1, x, y) for i, (x, y) in enumerate(zip(xa, xb)) if x != y]
                ocr = [s for s in swaps if frozenset(s[1] + s[2]) in OCR_DIGIT_PAIRS]
                if ocr and len(ocr) == len(swaps):
                    det.append("Every differing digit is a pair an OCR engine commonly confuses ("
                               + ", ".join(f"{x}/{y} at position {i}" for i, x, y in ocr) +
                               "). If this number was typed from a scan, check the original.")
            return done(Verdict("DIFF", FAIL, "Different number.", det))

    if kind == "number":
        na, nb = as_number(a_raw), as_number(b_raw)
        if na is not None and nb is not None:
            if abs(na - nb) < 1e-9:
                return done(Verdict("FORMAT", sev["FORMAT"], "Same value, written differently.",
                                    [f"Both equal {na:g}; only trailing zeros, a comma or a stray "
                                     f"space differ."]))
            return done(Verdict("DIFF", FAIL, "Different value.",
                                [f"The spreadsheet says {na:g}; the PDF says {nb:g} — a difference "
                                 f"of {nb - na:g}."]))

    if alnum(a_raw) == alnum(b_raw):
        accent_only = lowered(deaccent(clean(a_raw))) == lowered(deaccent(clean(b_raw)))
        code = "DIACRITIC" if accent_only else "PUNCT"
        return done(Verdict(code, sev[code],
                            "Same text, different accent marks." if accent_only
                            else "Same letters and digits, different punctuation.",
                            ["One side writes a letter with an accent that the other writes plain."]
                            if accent_only else _punct_details(a_raw, b_raw)))

    if squashed(a_raw) == squashed(b_raw):
        wa, wb = len(tokens(a_raw)), len(tokens(b_raw))
        return done(Verdict("WS", sev["WS"], "Same letters, split into words differently.",
                            [f"The spreadsheet writes it as {plural(wa, 'word', 'words')}, "
                             f"the PDF as {wb}.",
                             "Read end to end the characters are identical, so this is a spacing "
                             "difference rather than a spelling one."]))

    if ignore_honorifics and kind == "name":
        sa, ra = strip_honorifics(a_raw)
        sb, rb = strip_honorifics(b_raw)
        if (ra or rb) and lowered(sa) == lowered(sb):
            return done(Verdict("HONORIFIC", sev["HONORIFIC"],
                                "Same name once titles are removed.",
                                ["Removed: " + ", ".join(quote(x) for x in (ra + rb)) + ".",
                                 f"Both reduce to {quote(collapsed(sa))}."]))

    if sorted(tokens(a_raw)) == sorted(tokens(b_raw)) and len(tokens(a_raw)) > 1:
        return done(Verdict("ORDER", sev["ORDER"], "Same words, different order.",
                            [f"Spreadsheet order: {collapsed(a_raw)}.",
                             f"PDF order: {collapsed(b_raw)}.",
                             "Usually surname-first against given-name-first rather than a "
                             "different person."]))

    code, details, counts = _word_details(a_raw, b_raw)
    pct = round(sim * 100)
    if code == "SPELL":
        summary = plural(counts["spellings"], "word is spelt differently",
                         "words are spelt differently") + f" ({pct}% alike)."
    elif code == "INITIAL":
        summary = "One side uses a short form of a name."
    elif counts["missing"] and not counts["extra"]:
        summary = plural(counts["missing"], "word is", "words are") + " missing from the PDF."
    elif counts["extra"] and not counts["missing"]:
        summary = "The PDF has " + plural(counts["extra"], "extra word", "extra words") + "."
    else:
        summary = f"Different words ({pct}% alike)."
    verdict = Verdict(code, sev.get(code, FAIL), summary, details)
    if sim < 0.4:
        verdict.code, verdict.verdict = "DIFF", FAIL
        verdict.summary = f"These do not look like the same value ({pct}% alike)."
    return done(verdict)


def _forensic_report(a: str, b: str) -> list[str]:
    """Code-point level account of the first differences. Forensic mode only."""
    out = ["Code points, spreadsheet against PDF:"]
    common = min(len(a), len(b))
    shown = 0
    for i in range(common):
        if a[i] == b[i]:
            continue
        shown += 1
        if shown > 12:
            out.append("  … further differences not listed.")
            break
        out.append(f"  position {i + 1}: {codepoint_note(a[i])}  |  {codepoint_note(b[i])}")
    if len(a) != len(b):
        longer, tail = ("spreadsheet", a[common:]) if len(a) > len(b) else ("PDF", b[common:])
        out.append(f"  from position {common + 1} the {longer} value continues with "
                   f"{len(tail)} more character(s): {quote(tail[:40])}")
    elif shown == 0:
        out.append("  identical at every code point.")
    return out


# ----------------------------------------------------------------------------
# reading the spreadsheet
# ----------------------------------------------------------------------------

def col_letter(idx: int) -> str:
    s = ""
    idx += 1
    while idx > 0:
        idx, r = divmod(idx - 1, 26)
        s = chr(65 + r) + s
    return s


def col_index(letter: str) -> int:
    n = 0
    for ch in letter.strip().upper():
        if not ch.isalpha():
            raise ValueError(f"{letter!r} is not a column letter")
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def cell_text(cell) -> str:
    """The value as a person would read it, with long IDs kept intact.

    openpyxl hands back a float for a numeric cell. str(float) on an integer
    id gives '251512200006.0', and Excel's own display gives '2.51512E+11'.
    Neither is the number, so integers are rendered without a decimal tail.
    """
    v = cell.value
    if v is None:
        return ""
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (datetime, date)):
        return v.strftime("%d-%m-%Y")
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() and abs(v) < 1e15 else repr(v)
    if isinstance(v, int):
        return str(v)
    return str(v)


def load_sheet(path: str, sheet: Optional[str]) -> tuple[list[list[str]], str, list[str]]:
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True, read_only=True)
    names = list(wb.sheetnames)
    name = sheet or names[0]
    if name not in names:
        raise SystemExit(f"No sheet called {name!r}. This file has: {', '.join(names)}")
    ws = wb[name]
    rows = [[cell_text(c) for c in row] for row in ws.iter_rows()]
    wb.close()
    width = max((len(r) for r in rows), default=0)
    rows = [r + [""] * (width - len(r)) for r in rows]
    return rows, name, names


def guess_header_row(rows: list[list[str]]) -> int:
    best, best_score = 0, -1
    for i, row in enumerate(rows[:25]):
        filled = [collapsed(v) for v in row if collapsed(v)]
        if len(filled) < 2:
            continue
        text = " ".join(filled).lower()
        score = sum(1 for v in filled if len(v) <= 34)
        if re.search(r"\bname\b", text):
            score += 5
        if re.search(r"enrol|registration|reg\.?\s*no|roll", text):
            score += 5
        if re.search(r"remark|data|marksheet|meritto", text):
            score += 3
        if re.search(r"sl\.?\s*no|s\.?\s*no|sr\.?\s*no", text):
            score += 2
        if score > best_score:
            best, best_score = i, score
    return best


@dataclass
class Column:
    index: int
    letter: str
    header: str
    sample: str


def build_columns(rows: list[list[str]], header_row: int) -> list[Column]:
    header = rows[header_row] if header_row < len(rows) else []
    width = max((len(r) for r in rows), default=0)
    cols: list[Column] = []
    for c in range(width):
        sample = ""
        for r in range(header_row + 1, min(len(rows), header_row + 60)):
            v = clean(rows[r][c]).strip() if c < len(rows[r]) else ""
            if v:
                sample = v
                break
        cols.append(Column(c, col_letter(c),
                           collapsed(header[c]) if c < len(header) else "", sample))
    return cols


def auto_map(cols: list[Column]) -> tuple[int, int, list[int]]:
    reg = name = -1
    data: list[int] = []
    for c in cols:
        h = c.header.lower()
        if reg < 0 and re.search(r"enrol|registration|reg\.?\s*no|roll\s*no|student\s*id", h):
            reg = c.index
        if name < 0 and re.search(r"(student|candidate)\s*name|name of student|^name$", h):
            name = c.index
    if reg < 0:
        for c in cols:
            if len(digits_of(c.sample)) >= 9:
                reg = c.index
                break
    if name < 0:
        for c in cols:
            if "name" in c.header.lower():
                name = c.index
                break
    for c in cols:
        if re.search(r"meritto|as per|10th|source|reference", c.header.lower()):
            data.append(c.index)
    if not data:
        for c in cols:
            if c.index in (reg, name):
                continue
            if re.match(r"^[A-Za-z][A-Za-z '().\/-]{2,40}\s*:\s*\S", c.sample):
                data.append(c.index)
                break
    return reg, name, data[:1]


PAIR_RE = re.compile(r"^\s*([A-Za-z][A-Za-z0-9 .'&()/-]{0,44}?)\s*:\s*(.*)$", re.S)
SPLIT_SEMI = re.compile(r";\s*(?=[A-Za-z][^:;]{1,40}\s*:)")


@dataclass
class Pair:
    label: str
    value: str
    fdef: Optional[FieldDef]


def parse_cell(text: str, column_header: str) -> tuple[list[Pair], Optional[str]]:
    """Turn a cell such as 'Name of Student : X\\nFather's Name : Y' into pairs."""
    raw = clean(text)
    if not raw.strip():
        return [], "empty"
    lines: list[str] = []
    for ln in raw.split("\n"):
        lines.extend(SPLIT_SEMI.split(ln))

    pairs: list[Pair] = []
    for line in lines:
        if not line.strip():
            continue
        m = PAIR_RE.match(line)
        if m:
            pairs.append(Pair(m.group(1).strip(), m.group(2), resolve_field(m.group(1))))
        elif pairs:
            pairs[-1].value += " " + line.strip()
    if pairs:
        return pairs, None

    fdef = resolve_field(column_header or "")
    if fdef:
        return [Pair(column_header, raw.strip(), fdef)], None
    return [], "no-label"


# ----------------------------------------------------------------------------
# matching rows to PDFs and running the checks
# ----------------------------------------------------------------------------

@dataclass
class Check:
    column: str
    cell_ref: str
    field_label: str
    excel_value: str
    pdf_value: str
    verdict: str
    code: str
    summary: str
    details: list[str]


@dataclass
class RowResult:
    row_no: int
    name: str
    registration_raw: str
    registration: str
    pdf_file: str = ""
    pdf_pages: str = ""
    matched_by: str = ""
    status: str = PASS
    note: str = ""
    checks: list[Check] = field(default_factory=list)


class RecordIndex:
    def __init__(self, records: list[PdfRecord]):
        self.records = records
        self.by_reg: dict[str, list[PdfRecord]] = defaultdict(list)
        self.by_file: dict[str, list[PdfRecord]] = defaultdict(list)
        self.by_text: dict[str, list[PdfRecord]] = defaultdict(list)
        self.by_abc: dict[str, list[PdfRecord]] = defaultdict(list)
        self.by_name: dict[str, list[PdfRecord]] = defaultdict(list)
        for r in records:
            if r.registration:
                self.by_reg[r.registration].append(r)
            for run in set(re.findall(r"\d{6,}", r.file)):
                self.by_file[run].append(r)
            for run in set(re.findall(r"\d{8,}", r.text)):
                self.by_text[run].append(r)
            abc = digits_of(r.fields.get("abc_id", ""))
            if abc:
                self.by_abc[abc].append(r)
            nm = squashed(r.fields.get("student_name", ""))
            if nm:
                self.by_name[nm].append(r)

    def find(self, reg: str, abc: str, name: str) -> tuple[list[PdfRecord], str]:
        if reg:
            for index, how in ((self.by_reg, "registration number printed in the PDF"),
                               (self.by_file, "registration number in the file name"),
                               (self.by_text, "registration number found in the PDF text")):
                if reg in index:
                    return index[reg], how
        if abc and abc in self.by_abc:
            return self.by_abc[abc], "ABC ID"
        nm = squashed(name)
        if nm and nm in self.by_name:
            return self.by_name[nm], "student name only — no number matched, so verify by hand"
        return [], ""


def run_checks(rows: list[list[str]], header_row: int, cols: list[Column],
               reg_col: int, name_col: int, data_cols: list[int],
               index: RecordIndex, mode: str, ignore_honorifics: bool,
               abc_col: int = -1,
               only_reg: str = "") -> tuple[list[RowResult], list[PdfRecord]]:
    results: list[RowResult] = []
    used: set[int] = set()

    for r in range(header_row + 1, len(rows)):
        row = rows[r]
        reg_raw = clean(row[reg_col]).strip() if 0 <= reg_col < len(row) else ""
        name = clean(row[name_col]).strip() if 0 <= name_col < len(row) else ""
        abc = clean(row[abc_col]).strip() if 0 <= abc_col < len(row) else ""
        if not reg_raw and not name:
            continue
        if only_reg and id_digits(reg_raw)[0] != only_reg:
            continue

        res = RowResult(row_no=r + 1, name=name, registration_raw=reg_raw,
                        registration=id_digits(reg_raw)[0])
        hits, how = index.find(res.registration, digits_of(abc), name)
        if not hits:
            res.status = "nopdf"
            res.note = (f"No PDF carries the number {res.registration}."
                        if res.registration else
                        "This row has no registration number and no PDF matched the name.")
            results.append(res)
            continue

        rec = hits[0]
        used.add(id(rec))
        res.pdf_file = rec.file
        res.pdf_pages = ", ".join(str(p) for p in rec.pages)
        res.matched_by = how
        if len(hits) > 1:
            res.note = (f"{len(hits)} PDFs matched this student "
                        f"({', '.join(h.file for h in hits[:4])}). The first was used.")

        for ci in data_cols:
            col = cols[ci] if ci < len(cols) else Column(ci, col_letter(ci), "", "")
            cell = row[ci] if ci < len(row) else ""
            pairs, problem = parse_cell(cell, col.header)
            ref = f"{col.letter}{r + 1}"
            if problem == "empty":
                res.checks.append(Check(col.letter, ref, col.header or f"column {col.letter}",
                                        "", "", WARN, "EMPTY_EXCEL",
                                        f"Column {col.letter} is empty for this student.", []))
                continue
            if problem == "no-label":
                res.checks.append(Check(
                    col.letter, ref, col.header or f"column {col.letter}",
                    clean(cell).strip(), "", WARN, "NO_FIELD",
                    "Could not tell which field this cell holds.",
                    ["The cell holds a bare value with no “Label :” in front of it, and the column "
                     f"title {quote(col.header or '(none)')} does not name a grade-sheet field.",
                     "Either write the cell as “Father's Name : …”, or rename the column."]))
                continue
            for p in pairs:
                kind = p.fdef.kind if p.fdef else "text"
                pdf_val = rec.value(p.fdef, p.label)
                v = compare(p.value, pdf_val, kind, mode, ignore_honorifics)
                label = p.fdef.label if p.fdef else collapsed(p.label)
                if not p.fdef and not pdf_val:
                    v = Verdict("UNKNOWN_FIELD", FAIL,
                                f"{quote(collapsed(p.label))} is not a field this PDF carries.",
                                ["The label was not recognised as a standard grade-sheet field and "
                                 "no line in the PDF starts with it.",
                                 "Check the spelling of the label inside the spreadsheet cell."])
                res.checks.append(Check(col.letter, ref, label, clean(p.value),
                                        clean(pdf_val), v.verdict, v.code, v.summary, v.details))

        if any(c.verdict == FAIL for c in res.checks):
            res.status = FAIL
        elif any(c.verdict == WARN for c in res.checks):
            res.status = WARN
        else:
            res.status = PASS if res.checks else WARN
        results.append(res)

    orphans = [r for r in index.records if id(r) not in used]
    return results, orphans


# ----------------------------------------------------------------------------
# reports
# ----------------------------------------------------------------------------

REPORT_HEADER = ["Sheet row", "Student (spreadsheet)", "Registration", "PDF file", "PDF page(s)",
                 "Matched by", "Column", "Cell", "Field", "Spreadsheet value", "PDF value",
                 "Verdict", "What differs", "Explanation"]

VERDICT_WORD = {PASS: "Match", WARN: "Check", FAIL: "Mismatch", "nopdf": "No PDF"}


def report_rows(results: list[RowResult]) -> list[list[str]]:
    out = [REPORT_HEADER]
    for r in results:
        if r.status == "nopdf":
            out.append([r.row_no, r.name, r.registration_raw, "", "", "", "", "", "", "", "",
                        "No PDF", r.note, ""])
            continue
        for c in r.checks:
            out.append([r.row_no, r.name, r.registration_raw, r.pdf_file, r.pdf_pages,
                        r.matched_by, c.column, c.cell_ref, c.field_label,
                        c.excel_value, c.pdf_value, VERDICT_WORD.get(c.verdict, c.verdict),
                        c.summary, " ".join(c.details)])
    return out


def summarise(results: list[RowResult], orphans: list[PdfRecord]) -> dict:
    checks = [c for r in results for c in r.checks]
    codes = Counter(c.code for c in checks)
    return {
        "rows": len(results),
        "rows_no_pdf": sum(1 for r in results if r.status == "nopdf"),
        "rows_clean": sum(1 for r in results if r.status == PASS),
        "rows_warn": sum(1 for r in results if r.status == WARN),
        "rows_failed": sum(1 for r in results if r.status == FAIL),
        "fields_compared": len(checks),
        "fields_pass": sum(1 for c in checks if c.verdict == PASS),
        "fields_warn": sum(1 for c in checks if c.verdict == WARN),
        "fields_fail": sum(1 for c in checks if c.verdict == FAIL),
        "orphan_pdfs": len(orphans),
        "by_code": dict(codes.most_common()),
    }


def write_xlsx(path: Path, results: list[RowResult], orphans: list[PdfRecord],
               summary: dict, meta: dict) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    head_font = Font(name="Arial", bold=True, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="0B6E9B")
    fills = {"Match": PatternFill("solid", fgColor="E0F1E8"),
             "Check": PatternFill("solid", fgColor="FBEED7"),
             "Mismatch": PatternFill("solid", fgColor="FBE5E2"),
             "No PDF": PatternFill("solid", fgColor="F3D6D2")}
    body = Font(name="Arial", size=10)

    wb = Workbook()

    ws = wb.active
    ws.title = "Summary"
    ws.append(["Grade sheet verification"])
    ws["A1"].font = Font(name="Arial", bold=True, size=14)
    ws.append([])
    for k, v in meta.items():
        ws.append([k, v])
    ws.append([])
    ws.append(["Counts", ""])
    ws[f"A{ws.max_row}"].font = Font(name="Arial", bold=True)
    labels = [("Student rows", "rows"), ("Rows with no PDF", "rows_no_pdf"),
              ("Rows fully clean", "rows_clean"), ("Rows with close calls", "rows_warn"),
              ("Rows with a mismatch", "rows_failed"), ("Fields compared", "fields_compared"),
              ("Fields matching", "fields_pass"), ("Fields flagged", "fields_warn"),
              ("Fields mismatched", "fields_fail"), ("PDFs with no row", "orphan_pdfs")]
    for label, key in labels:
        ws.append([label, summary[key]])
    ws.append([])
    ws.append(["Difference type", "Count"])
    ws[f"A{ws.max_row}"].font = Font(name="Arial", bold=True)
    ws[f"B{ws.max_row}"].font = Font(name="Arial", bold=True)
    for code, n in summary["by_code"].items():
        ws.append([CODE_TEXT.get(code, code), n])
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 52
    for row in ws.iter_rows():
        for c in row:
            if not c.font.bold:
                c.font = body

    det = wb.create_sheet("Findings")
    rows = report_rows(results)
    for row in rows:
        det.append(row)
    for c in det[1]:
        c.font, c.fill = head_font, head_fill
        c.alignment = Alignment(vertical="center")
    widths = [9, 26, 16, 28, 10, 24, 8, 8, 20, 34, 34, 11, 36, 70]
    for i, w in enumerate(widths, 1):
        det.column_dimensions[get_column_letter(i)].width = w
    for r in range(2, det.max_row + 1):
        verdict = det.cell(r, 12).value
        fill = fills.get(verdict)
        for c in range(1, len(REPORT_HEADER) + 1):
            cell = det.cell(r, c)
            cell.font = body
            cell.alignment = Alignment(vertical="top", wrap_text=c in (10, 11, 13, 14))
            if fill:
                cell.fill = fill
    det.freeze_panes = "A2"
    det.auto_filter.ref = f"A1:{get_column_letter(len(REPORT_HEADER))}{det.max_row}"

    if orphans:
        orp = wb.create_sheet("PDFs with no row")
        orp.append(["PDF file", "Page(s)", "Registration in PDF", "Student name in PDF"])
        for c in orp[1]:
            c.font, c.fill = head_font, head_fill
        for rec in orphans:
            orp.append([rec.file, ", ".join(str(p) for p in rec.pages),
                        rec.registration or "(none found)",
                        rec.fields.get("student_name", "")])
        for i, w in enumerate((36, 10, 20, 30), 1):
            orp.column_dimensions[get_column_letter(i)].width = w
        for row in orp.iter_rows(min_row=2):
            for c in row:
                c.font = body

    wb.save(path)


CODE_TEXT = {
    "EXACT": "Exact match",
    "WS": "Spacing only",
    "CASE": "Capitalisation only",
    "PUNCT": "Punctuation only",
    "DIACRITIC": "Accent marks only",
    "FORMAT": "Same value, different format",
    "HONORIFIC": "Title or prefix only",
    "ORDER": "Same words, different order",
    "INITIAL": "Short form of a name",
    "SPELL": "Spelling differs",
    "WORDS": "Words added or missing",
    "DIFF": "Different value",
    "MISSING_IN_PDF": "Field not found in the PDF",
    "EMPTY_EXCEL": "Spreadsheet cell empty",
    "NO_FIELD": "Cell has no field label",
    "UNKNOWN_FIELD": "Label not a grade-sheet field",
}


def write_csv(path: Path, results: list[RowResult]) -> None:
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        csv.writer(fh).writerows(report_rows(results))


def write_json(path: Path, results: list[RowResult], orphans: list[PdfRecord],
               summary: dict, meta: dict) -> None:
    payload = {
        "tool": "gradesheet_verify", "version": __version__,
        "generated": datetime.now().isoformat(timespec="seconds"),
        "settings": meta, "summary": summary,
        "results": [asdict(r) for r in results],
        "orphan_pdfs": [{"file": r.file, "pages": r.pages, "registration": r.registration,
                         "student_name": r.fields.get("student_name", "")} for r in orphans],
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), "utf-8")


# ----------------------------------------------------------------------------
# console output
# ----------------------------------------------------------------------------

class Ink:
    def __init__(self, enabled: bool):
        self.on = enabled

    def _w(self, code: str, s: str) -> str:
        return f"\033[{code}m{s}\033[0m" if self.on else s

    def bold(self, s): return self._w("1", s)
    def dim(self, s): return self._w("2", s)
    def green(self, s): return self._w("32", s)
    def amber(self, s): return self._w("33", s)
    def red(self, s): return self._w("31", s)
    def blue(self, s): return self._w("36", s)

    def verdict(self, v: str) -> str:
        return {PASS: self.green("  match"), WARN: self.amber("  check"),
                FAIL: self.red("  MISMATCH"), "nopdf": self.red("  NO PDF")}.get(v, v)


def print_columns(cols: list[Column], ink: Ink) -> None:
    print(ink.bold("\n  Columns found\n"))
    for c in cols:
        if not c.header and not c.sample:
            continue
        sample = c.sample.replace("\n", " · ")
        if len(sample) > 58:
            sample = sample[:57] + "…"
        print(f"   {ink.blue(c.letter.rjust(3))}  {(c.header or '(no title)')[:30]:<32}"
              f"{ink.dim(sample)}")
    print()


def ask_columns(cols: list[Column], reg: int, name: int, data: list[int],
                ink: Ink) -> tuple[int, int, list[int]]:
    print_columns(cols, ink)

    def ask_one(prompt: str, default: int) -> int:
        d = col_letter(default) if default >= 0 else ""
        raw = input(f"   {prompt}" + (f" [{d}]" if d else "") + ": ").strip()
        if not raw:
            return default
        try:
            return col_index(raw)
        except ValueError:
            print(ink.red("   Not a column letter. Using the default."))
            return default

    reg = ask_one("Registration / enrolment number column", reg)
    name = ask_one("Student name column", name)
    d_default = ",".join(col_letter(i) for i in data)
    raw = input(f"   Column(s) to check against the PDF, comma separated"
                + (f" [{d_default}]" if d_default else "") + ": ").strip()
    if raw:
        picked = []
        for part in raw.split(","):
            part = part.strip()
            if not part:
                continue
            try:
                picked.append(col_index(part))
            except ValueError:
                print(ink.red(f"   Ignoring {part!r}, not a column letter."))
        if picked:
            data = picked
    return reg, name, data


def print_findings(results: list[RowResult], ink: Ink, only_problems: bool, limit: int) -> None:
    shown = 0
    for r in results:
        if only_problems and r.status in (PASS,):
            continue
        if shown >= limit:
            print(ink.dim(f"\n   … more rows not shown. The full report has everything."))
            break
        shown += 1
        head = f"\n  row {r.row_no}  {ink.bold(r.name or '(no name)')}  {ink.dim(r.registration)}"
        print(head + ink.verdict(r.status))
        if r.pdf_file:
            print(ink.dim(f"        {r.pdf_file}  ·  matched by {r.matched_by}"))
        if r.note:
            print(ink.amber(f"        {r.note}"))
        for c in r.checks:
            if only_problems and c.verdict == PASS:
                continue
            print(f"        {ink.blue(c.column)}  {c.field_label:<22}{ink.verdict(c.verdict)}"
                  f"   {c.summary}")
            if c.verdict != PASS:
                print(ink.dim(f"           spreadsheet : {c.excel_value}"))
                print(ink.dim(f"           PDF         : {c.pdf_value or '(not found)'}"))
                for d in c.details:
                    print(ink.dim(f"           · {d}"))


# ----------------------------------------------------------------------------
# command line
# ----------------------------------------------------------------------------

def gather_pdfs(paths: list[str], recursive: bool, limit: int) -> list[str]:
    found: list[str] = []
    for p in paths:
        path = Path(p)
        if path.is_dir():
            it = path.rglob("*") if recursive else path.glob("*")
            found += [str(f) for f in sorted(it) if f.suffix.lower() == ".pdf"]
        elif path.suffix.lower() == ".pdf":
            found.append(str(path))
    seen, out = set(), []
    for f in found:
        if f not in seen:
            seen.add(f)
            out.append(f)
    return out[:limit] if limit else out


def extract_all(paths: list[str], workers: int, max_pages: int,
                cache: ExtractionCache, ink: Ink) -> tuple[list[PdfRecord], list[dict], list[str]]:
    records: list[PdfRecord] = []
    failures: list[dict] = []
    no_text: list[str] = []

    pending: list[str] = []
    for p in paths:
        hit = cache.get(f"{file_digest(p)}:{max_pages}")
        if hit is None:
            pending.append(p)
        else:
            _absorb(hit, records, failures, no_text)

    if pending:
        bar = Progress(len(pending), "  reading PDFs")
        if workers > 1 and len(pending) > 1:
            with ProcessPoolExecutor(max_workers=workers) as pool:
                futures = {pool.submit(read_pdf, p, max_pages): p for p in pending}
                for fut in as_completed(futures):
                    p = futures[fut]
                    try:
                        out = fut.result()
                    except Exception as exc:
                        out = {"ok": False, "file": os.path.basename(p), "path": p,
                               "error": f"{type(exc).__name__}: {exc}", "records": []}
                    cache.put(f"{file_digest(p)}:{max_pages}", out)
                    _absorb(out, records, failures, no_text)
                    bar.update(1)
        else:
            for p in pending:
                out = read_pdf(p, max_pages)
                cache.put(f"{file_digest(p)}:{max_pages}", out)
                _absorb(out, records, failures, no_text)
                bar.update(1)
        bar.close()
    return records, failures, no_text


def _absorb(out: dict, records: list[PdfRecord], failures: list[dict], no_text: list[str]) -> None:
    if not out.get("ok"):
        failures.append(out)
        return
    if out.get("no_text"):
        no_text.append(out["file"])
    for r in out.get("records", []):
        records.append(PdfRecord(file=r["file"], pages=r["pages"],
                                 registration=r["registration"], fields=r["fields"],
                                 loose=r["loose"], text=r["text"]))


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="gradesheet_verify",
        description="Check that the values in a spreadsheet match the grade-sheet PDFs.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""examples
  Interactive, it shows the sheet and asks which columns to use:
      python gradesheet_verify.py --pdfs ./pdfs --excel sheet.xlsx

  Unattended, strict, writing an Excel report:
      python gradesheet_verify.py --pdfs ./pdfs --excel sheet.xlsx \\
          --header-row 5 --reg-col C --name-col B --data-cols F,G \\
          --mode strict --out report.xlsx

  Investigate one student:
      python gradesheet_verify.py --pdfs ./pdfs --excel sheet.xlsx --only 251512200009 --mode forensic

exit codes: 0 clean · 1 mismatches found · 2 bad input""")
    p.add_argument("--pdfs", nargs="+", required=True, metavar="PATH",
                   help="folders or .pdf files holding the grade sheets")
    p.add_argument("--excel", required=True, metavar="FILE", help="the spreadsheet to check")
    p.add_argument("--sheet", help="sheet name (default: the first one)")
    p.add_argument("--header-row", type=int, help="1-based row holding the column titles")
    p.add_argument("--reg-col", help="column letter of the registration number")
    p.add_argument("--name-col", help="column letter of the student name")
    p.add_argument("--abc-col", help="column letter of the ABC ID, used as a fallback key")
    p.add_argument("--data-cols", help="comma separated column letters to check, e.g. F,G")
    p.add_argument("--mode", choices=("lenient", "standard", "strict", "forensic"),
                   default="standard",
                   help="lenient: formatting ignored · standard: formatting flagged · "
                        "strict: anything short of exact fails · forensic: strict plus a "
                        "code-point report (default: standard)")
    p.add_argument("--ignore-honorifics", action="store_true",
                   help="treat Mr/Smt/Late/S-o and similar prefixes as removable")
    p.add_argument("--only", metavar="REGNO", help="check a single registration number")
    p.add_argument("--out", metavar="FILE", help="Excel report to write (default report.xlsx)")
    p.add_argument("--csv", metavar="FILE", help="also write a CSV report")
    p.add_argument("--json", metavar="FILE", help="also write a JSON report for audit")
    p.add_argument("--max-pdfs", type=int, default=1000, help="cap the batch size (default 1000)")
    p.add_argument("--max-pages", type=int, default=6,
                   help="pages to read per PDF (default 6)")
    p.add_argument("--workers", type=int, default=min(8, (os.cpu_count() or 2)),
                   help="parallel PDF readers")
    p.add_argument("--no-recursive", action="store_true", help="do not descend into subfolders")
    p.add_argument("--cache", metavar="FILE", default=".gradesheet-cache.json",
                   help="extraction cache file, 'none' to disable")
    p.add_argument("--show", type=int, default=40, help="rows to print (default 40)")
    p.add_argument("--all", action="store_true", help="print clean rows too")
    p.add_argument("--quiet", action="store_true", help="only the summary")
    p.add_argument("--no-colour", action="store_true")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    ink = Ink(sys.stdout.isatty() and not args.no_colour)
    started = time.time()

    if not Path(args.excel).exists():
        print(ink.red(f"No such spreadsheet: {args.excel}"))
        return 2

    pdf_paths = gather_pdfs(args.pdfs, not args.no_recursive, args.max_pdfs)
    if not pdf_paths:
        print(ink.red("No PDFs found under " + ", ".join(args.pdfs)))
        return 2

    print(ink.bold(f"\n  {len(pdf_paths)} PDF(s) to read, {args.workers} at a time"))
    cache = ExtractionCache(None if args.cache == "none" else Path(args.cache))
    records, failures, no_text = extract_all(pdf_paths, args.workers, args.max_pages, cache, ink)
    cache.save()

    with_reg = sum(1 for r in records if r.registration)
    print(f"  {ink.green(str(len(records)))} grade sheet(s) read"
          f" · {with_reg} carry a registration number"
          f" · {ink.dim(f'{cache.hits} from cache')}")
    if no_text:
        print(ink.amber(f"  {len(no_text)} PDF(s) yielded no text at all. These are almost "
                        f"certainly scans; run OCR over them first."))
        for f in no_text[:5]:
            print(ink.dim(f"      {f}"))
    if failures:
        print(ink.red(f"  {len(failures)} PDF(s) could not be opened:"))
        for f in failures[:5]:
            print(ink.dim(f"      {f['file']}: {f['error']}"))

    rows, sheet_name, all_sheets = load_sheet(args.excel, args.sheet)
    if not rows:
        print(ink.red("That sheet is empty."))
        return 2
    header_row = (args.header_row - 1) if args.header_row else guess_header_row(rows)
    cols = build_columns(rows, header_row)
    reg, name, data = auto_map(cols)

    print(ink.bold(f"\n  {Path(args.excel).name} · sheet {sheet_name!r} · "
                   f"header on row {header_row + 1}"))

    if args.reg_col:
        reg = col_index(args.reg_col)
    if args.name_col:
        name = col_index(args.name_col)
    if args.data_cols:
        data = [col_index(x) for x in args.data_cols.split(",") if x.strip()]
    abc = col_index(args.abc_col) if args.abc_col else next(
        (c.index for c in cols if "abc" in c.header.lower()), -1)

    interactive = not args.data_cols and sys.stdin.isatty() and not args.quiet
    if interactive:
        reg, name, data = ask_columns(cols, reg, name, data, ink)
    elif not args.quiet:
        print_columns(cols, ink)

    if reg < 0 and name < 0:
        print(ink.red("  Neither a registration column nor a name column was identified. "
                      "Pass --reg-col."))
        return 2
    if not data:
        print(ink.red("  No column to check. Pass --data-cols, e.g. --data-cols F"))
        return 2

    print(f"  key: {ink.blue(col_letter(reg) if reg >= 0 else '—')}"
          f" · name: {ink.blue(col_letter(name) if name >= 0 else '—')}"
          f" · checking: {ink.blue(', '.join(col_letter(i) for i in data))}"
          f" · mode: {ink.blue(args.mode)}")

    only_reg = digits_of(args.only) if args.only else ""

    index = RecordIndex(records)
    results, orphans = run_checks(rows, header_row, cols, reg, name, data, index,
                                  args.mode, args.ignore_honorifics, abc, only_reg)
    if only_reg and not results:
        print(ink.red(f"  No row has registration {only_reg}."))
        return 2
    summary = summarise(results, orphans)

    if not args.quiet:
        print_findings(results, ink, only_problems=not (args.all or bool(only_reg)),
                       limit=args.show)

    print(ink.bold("\n  Summary"))
    print(f"    {summary['rows']} student rows · {summary['fields_compared']} fields compared")
    print(f"    {ink.green(str(summary['fields_pass']))} matching"
          f" · {ink.amber(str(summary['fields_warn']))} to check"
          f" · {ink.red(str(summary['fields_fail']))} mismatched")
    print(f"    {ink.red(str(summary['rows_no_pdf']))} rows with no PDF"
          f" · {summary['orphan_pdfs']} PDFs with no row")
    if summary["by_code"]:
        print(ink.bold("\n  Difference types"))
        for code, n in summary["by_code"].items():
            if code == "EXACT":
                continue
            print(f"    {str(n).rjust(5)}  {CODE_TEXT.get(code, code)}")

    meta = {
        "Spreadsheet": str(Path(args.excel).resolve()),
        "Sheet": sheet_name,
        "Header row": header_row + 1,
        "Key column": col_letter(reg) if reg >= 0 else "—",
        "Name column": col_letter(name) if name >= 0 else "—",
        "Columns checked": ", ".join(col_letter(i) for i in data),
        "Matching mode": args.mode,
        "Honorifics ignored": "yes" if args.ignore_honorifics else "no",
        "PDFs read": len(pdf_paths),
        "Grade sheets found": len(records),
        "Tool version": __version__,
        "Run at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }

    out = Path(args.out) if args.out else Path("report.xlsx")
    try:
        write_xlsx(out, results, orphans, summary, meta)
        print(ink.bold(f"\n  Report written to {out}"))
    except Exception as exc:
        print(ink.red(f"  Could not write {out}: {exc}"))
    if args.csv:
        write_csv(Path(args.csv), results)
        print(f"  CSV written to {args.csv}")
    if args.json:
        write_json(Path(args.json), results, orphans, summary, meta)
        print(f"  JSON written to {args.json}")

    print(ink.dim(f"  Finished in {time.time() - started:.1f}s\n"))
    return 1 if (summary["fields_fail"] or summary["rows_no_pdf"]) else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(130)
