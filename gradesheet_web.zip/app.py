#!/usr/bin/env python3
"""
app.py — browser frontend for gradesheet_verify.py

Run this locally:
    pip install flask
    python app.py

Then open http://127.0.0.1:5000 in your browser. You can browse to (or
drag-and-drop) a whole folder of PDFs and an Excel file from anywhere on
your computer — nothing needs to be pre-copied into any fixed folder.
"""

from __future__ import annotations

import shutil
import subprocess
import sys
import uuid
from pathlib import Path

from flask import Flask, request, render_template, send_file, jsonify

BASE_DIR = Path(__file__).parent.resolve()
SCRIPT = BASE_DIR / "gradesheet_verify.py"
UPLOAD_ROOT = BASE_DIR / "uploads"
REPORT_ROOT = BASE_DIR / "reports"
UPLOAD_ROOT.mkdir(exist_ok=True)
REPORT_ROOT.mkdir(exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024  # 1 GB uploads


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/run", methods=["POST"])
def run():
    job_id = uuid.uuid4().hex[:12]
    job_dir = UPLOAD_ROOT / job_id
    pdf_dir = job_dir / "pdfs"
    pdf_dir.mkdir(parents=True, exist_ok=True)

    # --- Save the uploaded PDFs (a whole folder can be selected/dropped) ---
    pdf_files = request.files.getlist("pdfs")
    if not pdf_files:
        return jsonify({"ok": False, "error": "No PDF files were uploaded."}), 400

    saved = 0
    for f in pdf_files:
        if not f.filename:
            continue
        # webkitrelativepath / drag-drop paths can include subfolders; keep them
        rel = Path(f.filename)
        dest = pdf_dir / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        f.save(dest)
        saved += 1

    if saved == 0:
        return jsonify({"ok": False, "error": "No PDF files were uploaded."}), 400

    # --- Save the uploaded spreadsheet ---
    excel_file = request.files.get("excel")
    if not excel_file or not excel_file.filename:
        return jsonify({"ok": False, "error": "No spreadsheet was uploaded."}), 400
    excel_path = job_dir / excel_file.filename
    excel_file.save(excel_path)

    # --- Build the command line for the existing script ---
    out_path = REPORT_ROOT / f"{job_id}_report.xlsx"
    cmd = [
        sys.executable, str(SCRIPT),
        "--pdfs", str(pdf_dir),
        "--excel", str(excel_path),
        "--out", str(out_path),
        "--quiet",
        "--no-colour",
        "--cache", "none",
    ]

    mode = request.form.get("mode")
    if mode:
        cmd += ["--mode", mode]
    header_row = request.form.get("header_row")
    if header_row:
        cmd += ["--header-row", header_row]
    reg_col = request.form.get("reg_col")
    if reg_col:
        cmd += ["--reg-col", reg_col]
    name_col = request.form.get("name_col")
    if name_col:
        cmd += ["--name-col", name_col]
    data_cols = request.form.get("data_cols")
    if data_cols:
        cmd += ["--data-cols", data_cols]
    if request.form.get("ignore_honorifics") == "on":
        cmd += ["--ignore-honorifics"]

    proc = subprocess.run(
        cmd, cwd=str(job_dir), stdin=subprocess.DEVNULL,
        capture_output=True, text=True, timeout=1800,
    )

    log = (proc.stdout or "") + (("\n" + proc.stderr) if proc.stderr else "")

    # exit code: 0 clean, 1 mismatches found, 2 bad input
    if proc.returncode == 2 or not out_path.exists():
        shutil.rmtree(job_dir, ignore_errors=True)
        return jsonify({"ok": False, "error": "The check could not be completed.",
                         "log": log}), 400

    return jsonify({
        "ok": True,
        "job_id": job_id,
        "download_url": f"/download/{job_id}",
        "mismatches": proc.returncode == 1,
        "log": log,
    })


@app.route("/download/<job_id>")
def download(job_id):
    safe_id = "".join(c for c in job_id if c.isalnum())
    path = REPORT_ROOT / f"{safe_id}_report.xlsx"
    if not path.exists():
        return "Report not found.", 404
    return send_file(path, as_attachment=True, download_name="gradesheet_report.xlsx")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
