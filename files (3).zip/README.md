# Grade sheet verifier

Two tools that do the same job: check that what a spreadsheet says about a
student matches what is printed on their grade sheet PDF.

| | Browser tool | Python tool |
|---|---|---|
| File | `grade-sheet-verifier.html` | `gradesheet_verify.py` |
| Install | none, open the file | `pip install -r requirements.txt` |
| Use | drag files in, click | command line |
| Batch | up to 1000 PDFs | unlimited, `--max-pdfs` caps it |
| 1000 PDFs | roughly 8–15 min, one core | about 1–2 min on 8 cores |
| Re-runs | re-reads every PDF | cached, near instant |
| Scheduling | no | cron, CI, exit codes |
| Extra checks | — | invisible characters, look-alike letters, mixed alphabets, OCR digit confusion, honorific stripping, code-point reports |

Use the browser tool for a one-off check or to hand to someone who does not
use a terminal. Use the Python tool when this runs every week, when the batch
is large, or when a mismatch has to be defended with evidence.

---

## Browser tool

Open `grade-sheet-verifier.html` in Chrome, Edge or Firefox. Nothing is
uploaded anywhere; every PDF is read inside the browser tab.

1. Drop in the PDFs, or pick a whole folder.
2. Drop in the spreadsheet.
3. Click the header row, pick the registration and name columns, tick the
   columns to check.
4. Compare. Export the findings as `.xlsx` or `.csv`.

It needs an internet connection the first time, because it pulls `pdf.js` and
`SheetJS` from a CDN.

---

## Python tool

    pip install -r requirements.txt
    python gradesheet_verify.py --pdfs ./pdfs --excel "Error sheet.xlsx"

With no column arguments it prints the sheet and asks which columns to use.
Give the arguments and it runs unattended:

    python gradesheet_verify.py \
        --pdfs ./pdfs --excel "Error sheet.xlsx" \
        --header-row 5 --reg-col C --name-col B --data-cols F,G \
        --mode strict --out report.xlsx --csv report.csv --json report.json

Investigate one student, with a character-by-character account:

    python gradesheet_verify.py --pdfs ./pdfs --excel sheet.xlsx \
        --only 251512200009 --mode forensic

### Matching modes

| Mode | Spacing, case, punctuation, number format | Word order, short forms | Different words |
|---|---|---|---|
| `lenient` | match | flagged | mismatch |
| `standard` (default) | flagged | mismatch | mismatch |
| `strict` | mismatch | mismatch | mismatch |
| `forensic` | mismatch, plus a code-point report on every field | mismatch | mismatch |

### Useful flags

    --ignore-honorifics   treat Mr / Smt / Late / S-o as removable
    --abc-col D           use the ABC ID as a fallback key
    --workers 8           parallel PDF readers
    --max-pages 6         pages to read per PDF
    --cache FILE          extraction cache, 'none' to disable
    --all                 print clean rows too
    --quiet               summary only

### Exit codes

    0   everything matched
    1   mismatches, or rows with no PDF
    2   bad input

So in a scheduled job, a non-zero exit means someone needs to look.

---

## What both tools report

- Spacing: extra, leading, trailing, and non-breaking spaces
- Capitalisation
- Punctuation and accent marks
- Words split differently, for example `Abdulkhalid` against `Abdul Khalid`
- Same words in a different order
- Spelling, naming the word and the letter position
- Short forms, for example `Muhammad Shiham K` against `Kottayil`
- Extra or missing words, named individually
- Dates that are the same date written differently, against genuinely
  different dates, including day/month swaps
- Digit transpositions in ID numbers
- Field missing from the PDF, no PDF for a number, two PDFs for one number,
  PDFs with no matching row

The Python tool adds:

- Invisible characters (zero-width spaces, soft hyphens, byte-order marks)
- Letters that imitate Latin letters (Cyrillic а, Greek ο and so on)
- Mixed alphabets inside one value
- Digits an OCR engine commonly confuses, and letters typed into a number
- Honorific and relationship prefixes
- A full code-point report in forensic mode

## Two things to watch in your data

Excel stores long enrolment numbers as numbers and shows them as
`2.51512E+11`. Anything reading the displayed text gets the wrong number. Both
tools read the underlying value instead, but format that column as **Text** so
no other system trips over it.

A scanned PDF with no text layer cannot be read. Both tools say so rather than
reporting a false mismatch. Run OCR over those first, for example
`ocrmypdf in.pdf out.pdf`.
